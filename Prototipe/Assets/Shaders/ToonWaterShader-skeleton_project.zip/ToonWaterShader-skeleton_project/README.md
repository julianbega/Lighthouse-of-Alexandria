# Toon Water Shader
Unity 2018.3 project source for completed [Toon Water Shader tutorial](https://roystan.net/articles/toon-water.html) from the site [roystan.net](https://roystan.net/).

![alt text](https://i.imgur.com/skPAzbz.png)
